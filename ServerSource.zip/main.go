package main

import (
	"server/app"
)

func main() {

	// Setup Routes
	app.Installing()

}
